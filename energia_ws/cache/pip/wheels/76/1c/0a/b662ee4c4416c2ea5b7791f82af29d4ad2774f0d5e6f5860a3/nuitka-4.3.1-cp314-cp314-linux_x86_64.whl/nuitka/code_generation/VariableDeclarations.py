#     Copyright 2026, Kay Hayen, mailto:kay.hayen@gmail.com find license text at end of file


"""Variable declarations
Holds the information necessary to make C code declarations related to a variable.

"""

from contextlib import contextmanager

from .c_types.CTypeBooleans import CTypeBool
from .c_types.CTypeCFloats import CTypeCFloat
from .c_types.CTypeCLongs import CTypeCLong, CTypeCLongDigit
from .c_types.CTypeModuleDictVariables import CTypeModuleDictVariable
from .c_types.CTypeNuitkaBooleans import CTypeNuitkaBoolEnum
from .c_types.CTypeNuitkaInts import CTypeNuitkaIntOrLongStruct
from .c_types.CTypeNuitkaVoids import CTypeNuitkaVoidEnum
from .c_types.CTypePyObjectPointers import (
    CTypeCellObject,
    CTypePyCellObject,
    CTypePyObjectPtr,
    CTypePyObjectPtrPtr,
)


class VariableDeclaration(object):
    __slots__ = (
        "c_type",
        "code_name",
        "init_value",
        "heap_name",
        "struct_name",
        "maybe_unused",
    )

    def __init__(self, c_type, code_name, init_value, heap_name, struct_name):
        if c_type.startswith("NUITKA_MAY_BE_UNUSED"):
            self.c_type = c_type[21:]
            self.maybe_unused = True
        else:
            self.c_type = c_type
            self.maybe_unused = False

        self.code_name = code_name
        self.init_value = init_value
        self.heap_name = heap_name
        self.struct_name = struct_name

    def makeCFunctionLevelDeclaration(self):
        pos = self.c_type.find("[")
        if pos != -1:
            lead_c_type = self.c_type[:pos]
            suffix_c_type = self.c_type[pos:]
        else:
            lead_c_type = self.c_type
            suffix_c_type = ""

        return "%s%s%s%s%s%s;" % (
            "NUITKA_MAY_BE_UNUSED " if self.maybe_unused else "",
            lead_c_type,
            " " if lead_c_type[-1] != "*" else "",
            self.code_name,
            "" if self.init_value is None else " = %s" % self.init_value,
            suffix_c_type,
        )

    def makeCStructDeclaration(self):
        c_type = self.c_type

        if "[" in c_type:
            array_decl = c_type[c_type.find("[") :]
            c_type = c_type[: c_type.find("[")]
        else:
            array_decl = ""

        return "%s%s%s%s;" % (
            c_type,
            " " if self.c_type[-1] != "*" else "",
            self.code_name,
            array_decl,
        )

    def makeCStructInit(self):
        if self.init_value is None:
            return None

        if self.struct_name is not None:
            return "%s.%s = %s;" % (self.struct_name, self.code_name, self.init_value)

        assert self.heap_name, repr(self)

        return "%s->%s = %s;" % (self.heap_name, self.code_name, self.init_value)

    def getCType(self):
        # TODO: This ought to become unnecessary function
        # In the mean time, many cases: pylint: disable=too-many-return-statements

        c_type = self.c_type

        if c_type == "PyObject *":
            return CTypePyObjectPtr
        elif c_type == "struct Nuitka_CellObject *":
            return CTypeCellObject
        elif c_type == "PyCellObject *":
            return CTypePyCellObject
        elif c_type == "PyObject **":
            return CTypePyObjectPtrPtr
        elif c_type == "nuitka_bool":
            return CTypeNuitkaBoolEnum
        elif c_type == "bool":
            return CTypeBool
        elif c_type == "nuitka_ilong":
            return CTypeNuitkaIntOrLongStruct
        elif c_type == "module_var":
            return CTypeModuleDictVariable
        elif c_type == "nuitka_void":
            return CTypeNuitkaVoidEnum
        elif c_type == "long":
            return CTypeCLong
        elif c_type == "nuitka_digit":
            return CTypeCLongDigit
        elif c_type == "double":
            return CTypeCFloat

        assert False, c_type

    def __str__(self):
        if self.struct_name is not None:
            return "%s.%s" % (self.struct_name, self.code_name)
        elif self.heap_name:
            return "%s->%s" % (self.heap_name, self.code_name)
        else:
            return self.code_name

    def __repr__(self):
        return "<VariableDeclaration %s %s = %r>" % (
            self.c_type,
            self.code_name,
            self.init_value,
        )


class YieldTempsDeclaration(object):
    """Storage for temporaries preserved across a yield.

    Every yield site gets its own exact sized buffer, and the declaration is a
    union of these, so the storage is only as big as the maximum needed.
    """

    __slots__ = ("heap_name", "size_expressions")

    def __init__(self, heap_name):
        self.heap_name = heap_name
        self.size_expressions = []

    def addSizeExpression(self, size_expression):
        member_name = "yield_tmps_%d" % (len(self.size_expressions) + 1)
        self.size_expressions.append(size_expression)

        if self.heap_name is not None:
            return "%s->yield_tmps.%s" % (self.heap_name, member_name)

        return "yield_tmps.%s" % member_name

    def makeDeclaration(self):
        return "union {\n%s\n} yield_tmps;" % "\n".join(
            "char yield_tmps_%d[%s];" % (index + 1, size_expression)
            for index, size_expression in enumerate(self.size_expressions)
        )

    makeCStructDeclaration = makeDeclaration
    makeCFunctionLevelDeclaration = makeDeclaration

    @staticmethod
    def makeCStructInit():
        return None


class VariableStorage(object):
    # The storage for variable declarations, with a couple of attributes for
    # exception variables, pylint: disable=too-many-instance-attributes
    __slots__ = (
        "heap_name",
        "struct_name",
        "struct_type_name",
        "variable_declarations_heap",
        "variable_declarations_main",
        "variable_declarations_closure",
        "variable_declarations_locals",
        "exception_variable_name",
        "exception_lineno_count",
        "variable_declarations_top",
    )

    def __init__(self, heap_name, struct_name, struct_type_name):
        self.heap_name = heap_name
        self.struct_name = struct_name
        self.struct_type_name = struct_type_name

        self.variable_declarations_heap = []
        self.variable_declarations_main = []
        self.variable_declarations_closure = []

        self.variable_declarations_locals = []

        self.exception_variable_name = None
        self.exception_lineno_count = 0

        self.variable_declarations_top = {}

    @contextmanager
    def withLocalStorage(self):
        """Local storage for only just during context usage.

        This is for automatic removal of that scope. These are supposed
        to be nestable eventually.

        """

        self.variable_declarations_locals.append([])

        yield

        self.variable_declarations_locals.pop()

    def getVariableDeclarationTop(self, code_name):
        return self.variable_declarations_top.get(code_name)

    def getYieldTempsDeclaration(self):
        result = self.variable_declarations_top.get("yield_tmps")

        if result is None:
            result = YieldTempsDeclaration(heap_name=self.heap_name)
            self.variable_declarations_top["yield_tmps"] = result

            if self.heap_name is not None:
                self.variable_declarations_heap.append(result)
            else:
                self.variable_declarations_main.append(result)

        return result

    def getVariableDeclarationClosure(self, closure_index):
        return self.variable_declarations_closure[closure_index]

    def addFrameCacheDeclaration(self, frame_identifier):
        return self.addVariableDeclarationFunction(
            "static struct Nuitka_FrameObject *", "cache_%s" % frame_identifier, "NULL"
        )

    def makeCStructLevelDeclarations(self):
        return [
            variable_declaration.makeCStructDeclaration()
            for variable_declaration in self.variable_declarations_heap
        ]

    def makeCStructInits(self):
        result = []

        for variable_declaration in self.variable_declarations_heap:
            init_value = variable_declaration.makeCStructInit()

            if init_value is not None:
                result.append(init_value)

        return result

    def getExceptionVariableDescriptions(self):
        if self.exception_variable_name is None:
            self.exception_variable_name = (
                self.addVariableDeclarationTop(
                    "struct Nuitka_ExceptionPreservationItem",
                    "exception_state",
                    "Empty_Nuitka_ExceptionPreservationItem",
                ),
                self.addVariableDeclarationTop(
                    "NUITKA_MAY_BE_UNUSED int", "exception_lineno", "0"
                ),
            )

        return self.exception_variable_name

    def getExceptionVariableDescriptionsWithOwnLineno(self):
        # The exception state must remain shared across outline bodies, only
        # the line number is specific to the outline, so that the caller line
        # number is not overwritten by code inside of it.
        exception_state_name, _exception_lineno = (
            self.getExceptionVariableDescriptions()
        )

        self.exception_lineno_count += 1

        result_lineno = self.addVariableDeclarationTop(
            "NUITKA_MAY_BE_UNUSED int",
            "exception_lineno_%d" % self.exception_lineno_count,
            "0",
        )

        return (exception_state_name, result_lineno)

    def addVariableDeclarationLocal(self, c_type, code_name):
        result = VariableDeclaration(
            c_type=c_type,
            code_name=code_name,
            init_value=None,
            heap_name=None,
            struct_name=None,
        )

        self.variable_declarations_locals[-1].append(result)

        return result

    def addVariableDeclarationClosure(self, c_type, code_name):
        result = VariableDeclaration(
            c_type=c_type,
            code_name=code_name,
            init_value=None,
            heap_name=None,
            struct_name=None,
        )

        self.variable_declarations_closure.append(result)

        return result

    def addVariableDeclarationFunction(self, c_type, code_name, init_value):
        result = VariableDeclaration(
            c_type=c_type,
            code_name=code_name,
            init_value=init_value,
            heap_name=None,
            struct_name=None,
        )

        self.variable_declarations_main.append(result)
        assert code_name not in self.variable_declarations_top, (
            code_name,
            self.variable_declarations_top[code_name],
            result,
        )
        self.variable_declarations_top[code_name] = result

        return result

    def addVariableDeclarationTop(self, c_type, code_name, init_value):
        result = VariableDeclaration(
            c_type=c_type,
            code_name=code_name,
            init_value=init_value,
            heap_name=self.heap_name,
            struct_name=None,
        )

        if self.heap_name is not None:
            self.variable_declarations_heap.append(result)
        else:
            self.variable_declarations_main.append(result)

        assert code_name not in self.variable_declarations_top, (
            code_name,
            self.variable_declarations_top[code_name],
            result,
        )
        self.variable_declarations_top[code_name] = result

        return result

    def addVariableDeclarationFrameLocal(self, c_type, code_name, init_value):
        # Generator/heap contexts have no stack struct; degrade to top/heap.
        if self.struct_name is None:
            return self.addVariableDeclarationTop(c_type, code_name, init_value)

        result = VariableDeclaration(
            c_type=c_type,
            code_name=code_name,
            init_value=init_value,
            heap_name=None,
            struct_name=self.struct_name,
        )

        self.variable_declarations_heap.append(result)

        assert code_name not in self.variable_declarations_top, (
            code_name,
            self.variable_declarations_top[code_name],
            result,
        )
        self.variable_declarations_top[code_name] = result

        return result

    def makeCLocalDeclarations(self):
        return [
            variable_declaration.makeCFunctionLevelDeclaration()
            for variable_declaration in self.variable_declarations_locals[-1]
        ]

    def makeCFunctionLevelDeclarations(self):
        return [
            variable_declaration.makeCFunctionLevelDeclaration()
            for variable_declaration in self.variable_declarations_main
        ]

    def getLocalPreservationDeclarations(self):
        result = []

        for variable_declarations_local in self.variable_declarations_locals:
            result.extend(variable_declarations_local)

        return result


#     Part of "Nuitka", an optimizing Python compiler that is compatible and
#     integrates with CPython, but also works on its own.
#
#     Licensed under the GNU Affero General Public License, Version 3 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#        https://www.gnu.org/licenses/agpl-3.0.txt
#
#     See also: "Nuitka Runtime Library Exception, Version 1.0" in file
#     "LICENSE-RUNTIME.txt" for additional permissions granted under Section 7.
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.
