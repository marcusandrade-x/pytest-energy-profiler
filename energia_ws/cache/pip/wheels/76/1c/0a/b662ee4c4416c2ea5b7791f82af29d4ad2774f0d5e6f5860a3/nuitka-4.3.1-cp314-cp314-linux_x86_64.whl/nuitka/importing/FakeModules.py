#     Copyright 2026, Kay Hayen, mailto:kay.hayen@gmail.com find license text at end of file


"""Handling of fake module descriptions and reserved names."""

from nuitka.containers.Namedtuples import makeNamedtupleClass
from nuitka.utils.ModuleNames import ModuleName

from .ImportingResults import makeFindModuleResult

FakeModuleDescription = makeNamedtupleClass(
    "FakeModuleDescription",
    (
        "module_name",
        "source_code",
        "source_filename",
        "reason",
    ),
)

VirtualModuleInfo = makeNamedtupleClass(
    "VirtualModuleInfo",
    (
        "description",
        "plugin",
    ),
)

# Plugin provided fake modules, mapping module names to providing plugins.
_fake_modules = {}

# Plugin provided descriptions for virtual modules, i.e. modules that do not
# exist as files, but are provided at compile time with generated source code.
_virtual_modules = {}


def makeFakeModuleDescription(module_name, source_code, source_filename, reason):
    return FakeModuleDescription(
        module_name=module_name,
        source_code=source_code,
        source_filename=source_filename,
        reason=reason,
    )


def addFakeModule(module_name, plugin):
    assert type(module_name) is ModuleName, module_name

    _fake_modules[module_name] = plugin


def getFakeModulePlugin(module_name):
    return _fake_modules.get(module_name)


def locateFakeModule(module_name):
    if module_name in _fake_modules:
        return makeFindModuleResult(
            found_module_name=module_name,
            module_package=module_name.getPackageName(),
            module_filename=None,
            module_kind="py",
            finding="fake",
        )

    return None


def addVirtualModuleDescription(module_name, description, plugin):
    assert type(module_name) is ModuleName, module_name
    assert type(description) is FakeModuleDescription, description

    _virtual_modules[module_name] = VirtualModuleInfo(
        description=description,
        plugin=plugin,
    )


def getVirtualModuleDescription(module_name):
    virtual_module_info = _virtual_modules.get(module_name)

    if virtual_module_info is None:
        return None

    return virtual_module_info.description


def locateVirtualModule(module_name):
    if module_name in _virtual_modules:
        return makeFindModuleResult(
            found_module_name=module_name,
            module_package=module_name.getPackageName(),
            module_filename=None,
            module_kind="py",
            finding="virtual",
        )

    return None


#     Part of "Nuitka", an optimizing Python compiler that is compatible and
#     integrates with CPython, but also works on its own.
#
#     Licensed under the GNU Affero General Public License, Version 3 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#        https://www.gnu.org/licenses/agpl-3.0.txt
#
#     See also: "Nuitka Runtime Library Exception, Version 1.0" in file
#     "LICENSE-RUNTIME.txt" for additional permissions granted under Section 7.
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.
