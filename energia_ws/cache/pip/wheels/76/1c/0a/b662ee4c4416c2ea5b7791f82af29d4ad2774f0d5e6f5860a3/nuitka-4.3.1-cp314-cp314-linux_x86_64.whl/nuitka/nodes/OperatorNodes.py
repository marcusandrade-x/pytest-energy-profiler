#     Copyright 2026, Kay Hayen, mailto:kay.hayen@gmail.com find license text at end of file


"""Nodes for unary and binary operations.

No short-circuit involved, boolean 'not' is an unary operation like '-' is,
no real difference.
"""

import copy
from abc import abstractmethod

from nuitka.__past__ import long, unicode
from nuitka.Errors import NuitkaAssumptionError
from nuitka.PythonOperators import (
    binary_operator_functions,
    predictStringFormatSizeRange,
)
from nuitka.PythonVersions import python_version

from .ChildrenHavingMixins import ChildrenHavingLeftRightMixin
from .ExpressionBases import ExpressionBase
from .NodeMakingHelpers import (
    makeConstantReplacementNode,
    makeRaiseExceptionReplacementExpressionFromInstance,
    wrapExpressionWithSideEffects,
)
from .shapes.BuiltinTypeShapes import tshape_bool, tshape_int_or_long
from .shapes.StandardShapes import (
    ShapeLargeConstantValue,
    ShapeLargeConstantValuePredictable,
    ShapeLargeConstantValueRange,
    tshape_unknown,
    vshape_unknown,
)

# Limits for compile time constant folding, values taken from CPython.
MAX_INT_SIZE = 128  # bits
MAX_COLLECTION_SIZE = 256  # items
MAX_STR_SIZE = 4096  # characters
MAX_TOTAL_ITEMS = 1024  # including nested collections

_INT_TYPES = (int, long, bool)
_STR_TYPES = (str, bytes, unicode)
_COLLECTION_TYPES = (tuple, list, frozenset)


def _getIntBitLength(value):
    # The "bit_length" method is not available on Python 2.6.
    value = abs(value)

    if value == 0:
        return 0

    return len(bin(value)) - 2


def _computeComplexity(value, limit):
    """Compute the remaining item budget of nested collections.

    Notes:
        This emulates the 'check_complexity' function of CPython.

    Returns:
        Remaining item budget, negative if exceeded.

    """

    if type(value) in _COLLECTION_TYPES:
        limit -= len(value)

        for element in value:
            if limit < 0:
                break

            limit = _computeComplexity(element, limit)

    return limit


def _isTooLargeMultiply(left_value, right_value):
    """Check multiplication against the compile time limits of CPython."""

    left_type = type(left_value)
    right_type = type(right_value)

    result = False

    if left_type in _INT_TYPES and right_type in _INT_TYPES:
        if left_value and right_value:
            result = (
                _getIntBitLength(left_value) + _getIntBitLength(right_value)
                > MAX_INT_SIZE
            )
    elif left_type in _INT_TYPES or right_type in _INT_TYPES:
        if left_type in _INT_TYPES:
            count, sequence = left_value, right_value
        else:
            count, sequence = right_value, left_value

        sequence_type = type(sequence)

        if sequence_type in _STR_TYPES:
            if sequence:
                result = count < 0 or count > MAX_STR_SIZE // len(sequence)
        elif sequence_type in _COLLECTION_TYPES:
            size = len(sequence)

            if size:
                if count < 0 or count > MAX_COLLECTION_SIZE // size:
                    result = True
                else:
                    result = (
                        bool(count)
                        and _computeComplexity(sequence, MAX_TOTAL_ITEMS // count) < 0
                    )

    return result


def _isTooLargePower(left_value, right_value):
    """Check power against the compile time limits of CPython."""

    if type(left_value) in _INT_TYPES and type(right_value) in _INT_TYPES:
        if left_value and right_value > 0:
            if right_value > MAX_INT_SIZE:
                return True

            return _getIntBitLength(left_value) > MAX_INT_SIZE // right_value

    return False


def _isTooLargeLshift(left_value, right_value):
    """Check left shift against the compile time limits of CPython."""

    if type(left_value) in _INT_TYPES and type(right_value) in _INT_TYPES:
        if left_value and right_value:
            if right_value < 0 or right_value > MAX_INT_SIZE:
                return True

            return _getIntBitLength(left_value) > MAX_INT_SIZE - right_value

    return False


class ExpressionPropertiesFromTypeShapeMixin(object):
    """Given a self.type_shape, this can derive default properties from there."""

    # Mixins are required to define empty slots
    __slots__ = ()

    def isKnownToBeHashable(self):
        return self.type_shape.hasShapeSlotHash()


class ExpressionOperationBinaryBase(
    ExpressionPropertiesFromTypeShapeMixin, ChildrenHavingLeftRightMixin, ExpressionBase
):
    """Base class for all binary operation expression."""

    __slots__ = ("type_shape", "escape_desc", "inplace_suspect", "shape")

    named_children = ("left", "right")
    nice_children = tuple(child_name + " operand" for child_name in named_children)

    def __init__(self, left, right, source_ref):
        ChildrenHavingLeftRightMixin.__init__(self, left=left, right=right)

        ExpressionBase.__init__(self, source_ref)

        # Question might be asked early on, later this is cached from last computation.
        self.type_shape = tshape_unknown

        self.escape_desc = None

        self.inplace_suspect = False

        self.shape = vshape_unknown

    @staticmethod
    def isExpressionOperationBinary():
        return True

    def getOperator(self):
        return self.operator

    def markAsInplaceSuspect(self):
        self.inplace_suspect = True

    def removeMarkAsInplaceSuspect(self):
        self.inplace_suspect = False

    def isInplaceSuspect(self):
        return self.inplace_suspect

    def getOperands(self):
        return (self.subnode_left, self.subnode_right)

    def mayRaiseExceptionOperation(self):
        return self.escape_desc.getExceptionExit() is not None

    def mayRaiseException(self, exception_type):
        # TODO: Match getExceptionExit() more precisely against exception type given
        return (
            self.escape_desc is None
            or self.escape_desc.getExceptionExit() is not None
            or self.subnode_left.mayRaiseException(exception_type)
            or self.subnode_right.mayRaiseException(exception_type)
        )

    def getTypeShape(self):
        return self.type_shape

    @abstractmethod
    def _getOperationShape(self, left_shape, right_shape):
        pass

    @staticmethod
    def canCreateUnsupportedException(left_shape, right_shape):
        return hasattr(left_shape, "typical_value") and hasattr(
            right_shape, "typical_value"
        )

    def createUnsupportedException(self, left_shape, right_shape):
        left = left_shape.typical_value
        right = right_shape.typical_value

        try:
            self.simulator(left, right)
        except TypeError as e:
            return e
        except Exception as e:
            raise NuitkaAssumptionError(
                "Unexpected exception type doing operation simulation",
                self.operator,
                self.simulator,
                left_shape,
                right_shape,
                repr(left),
                repr(right),
                e,
                "!=",
            )
        else:
            raise NuitkaAssumptionError(
                "Unexpected no-exception doing operation simulation",
                self.operator,
                self.simulator,
                left_shape,
                right_shape,
                repr(left),
                repr(right),
            )

    @staticmethod
    def getTooLargeShape():
        """Shape of the operation, if it is too large to compute at compile time."""

        return None

    def _simulateOperation(self, trace_collection):
        left_value = self.subnode_left.getCompileTimeConstant()
        right_value = self.subnode_right.getCompileTimeConstant()

        # Avoid mutating owned by nodes values and potentially shared.
        if self.subnode_left.isMutable():
            left_value = copy.copy(left_value)

        return trace_collection.getCompileTimeComputationResult(
            node=self,
            computation=lambda: self.simulator(left_value, right_value),
            description="Operator '%s' with constant arguments." % self.operator,
        )

    def computeExpression(self, trace_collection):
        # Nothing to do anymore for large constants.
        if self.shape is not None and self.shape.isConstant():
            exception_raise_exit = self.escape_desc.getExceptionExit()
            if exception_raise_exit is not None:
                trace_collection.onExceptionRaiseExit(exception_raise_exit)
            return self, None, None

        left = self.subnode_left
        left_shape = left.getTypeShape()
        right = self.subnode_right
        right_shape = right.getTypeShape()

        self.type_shape, self.escape_desc = self._getOperationShape(
            left_shape, right_shape
        )

        if left.isCompileTimeConstant() and right.isCompileTimeConstant():
            too_large_shape = self.getTooLargeShape()

            if too_large_shape is None:
                return self._simulateOperation(trace_collection)

            self.shape = too_large_shape

        exception_raise_exit = self.escape_desc.getExceptionExit()
        if exception_raise_exit is not None:
            trace_collection.onExceptionRaiseExit(exception_raise_exit)

            if self.escape_desc.isUnsupported() and self.canCreateUnsupportedException(
                left_shape, right_shape
            ):
                result = wrapExpressionWithSideEffects(
                    new_node=makeRaiseExceptionReplacementExpressionFromInstance(
                        expression=self,
                        exception=self.createUnsupportedException(
                            left_shape,
                            right_shape,
                        ),
                    ),
                    old_node=self,
                    side_effects=(left, right),
                )

                return (
                    result,
                    "new_raise",
                    "Replaced operator '%s' with %s %s arguments that cannot work."
                    % (self.operator, left_shape, right_shape),
                )

        if self.escape_desc.isValueEscaping():
            # The value of these nodes escaped and could change its contents.
            trace_collection.removeKnowledge(left)
            trace_collection.removeKnowledge(right)

        if self.escape_desc.isControlFlowEscape():
            # Any code could be run, note that.
            trace_collection.onControlFlowEscape(self)

        return self, None, None

    @staticmethod
    def canPredictIterationValues():
        # TODO: Actually we could very well, esp. for sequence repeats.
        return False


class ExpressionOperationAddMixin(object):
    # Mixins are not allowed to specify slots.
    __slots__ = ()

    def getValueShape(self):
        return self.shape

    def getTooLargeShape(self):
        if self.subnode_left.isKnownToBeIterable(
            None
        ) and self.subnode_right.isKnownToBeIterable(None):
            size = (
                self.subnode_left.getIterationLength()
                + self.subnode_right.getIterationLength()
            )

            if size > 256:
                # TODO: Actually could make a predictor, but we don't use it yet.
                return ShapeLargeConstantValuePredictable(
                    size=size,
                    predictor=None,  # predictValuesFromRightAndLeftValue,
                    shape=self.subnode_left.getTypeShape(),
                )

        return None


class ExpressionOperationBinaryAdd(
    ExpressionOperationAddMixin, ExpressionOperationBinaryBase
):
    kind = "EXPRESSION_OPERATION_BINARY_ADD"

    def __init__(self, left, right, source_ref):
        ExpressionOperationBinaryBase.__init__(
            self, left=left, right=right, source_ref=source_ref
        )

    operator = "Add"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryAddShape(right_shape)


class ExpressionOperationBinarySub(ExpressionOperationBinaryBase):
    kind = "EXPRESSION_OPERATION_BINARY_SUB"

    operator = "Sub"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinarySubShape(right_shape)


class ExpressionOperationMultMixin(object):
    # Mixins are not allowed to specify slots.
    __slots__ = ()

    def getValueShape(self):
        return self.shape

    def getTooLargeShape(self):
        left_value = self.subnode_left.getCompileTimeConstant()
        right_value = self.subnode_right.getCompileTimeConstant()

        if not _isTooLargeMultiply(left_value, right_value):
            return None

        left_type = type(left_value)
        right_type = type(right_value)

        if left_type in _INT_TYPES and right_type not in _INT_TYPES:
            size = len(right_value) * max(left_value, 0)

            return ShapeLargeConstantValuePredictable(
                size=size,
                predictor=None,  # predictValuesFromRightAndLeftValue,
                shape=self.subnode_right.getTypeShape(),
            )
        elif right_type in _INT_TYPES and left_type not in _INT_TYPES:
            size = len(left_value) * max(right_value, 0)

            return ShapeLargeConstantValuePredictable(
                size=size,
                predictor=None,  # predictValuesFromRightAndLeftValue,
                shape=self.subnode_left.getTypeShape(),
            )
        else:
            return ShapeLargeConstantValue(size=None, shape=tshape_int_or_long)


class ExpressionOperationBinaryMult(
    ExpressionOperationMultMixin, ExpressionOperationBinaryBase
):
    kind = "EXPRESSION_OPERATION_BINARY_MULT"

    operator = "Mult"
    simulator = binary_operator_functions[operator]

    def __init__(self, left, right, source_ref):
        ExpressionOperationBinaryBase.__init__(
            self, left=left, right=right, source_ref=source_ref
        )

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryMultShape(right_shape)

    def getIterationLength(self):
        left_length = self.subnode_left.getIterationLength()

        if left_length is not None:
            right_value = self.subnode_right.getIntegerValue()

            if right_value is not None:
                return left_length * right_value

        right_length = self.subnode_right.getIterationLength()

        if right_length is not None:
            left_value = self.subnode_left.getIntegerValue()

            if left_value is not None:
                return right_length * left_value

        return ExpressionOperationBinaryBase.getIterationLength(self)

    def extractSideEffects(self):
        left_length = self.subnode_left.getIterationLength()

        if left_length is not None:
            right_value = self.subnode_right.getIntegerValue()

            if right_value is not None:
                return (
                    self.subnode_left.extractSideEffects()
                    + self.subnode_right.extractSideEffects()
                )

        right_length = self.subnode_right.getIterationLength()

        if right_length is not None:
            left_value = self.subnode_left.getIntegerValue()

            if left_value is not None:
                return (
                    self.subnode_left.extractSideEffects()
                    + self.subnode_right.extractSideEffects()
                )

        return ExpressionOperationBinaryBase.extractSideEffects(self)


class ExpressionOperationBinaryFloorDiv(ExpressionOperationBinaryBase):
    kind = "EXPRESSION_OPERATION_BINARY_FLOOR_DIV"

    operator = "FloorDiv"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryFloorDivShape(right_shape)


if python_version < 0x300:

    class ExpressionOperationBinaryOldDiv(ExpressionOperationBinaryBase):
        kind = "EXPRESSION_OPERATION_BINARY_OLD_DIV"

        operator = "OldDiv"
        simulator = binary_operator_functions[operator]

        @staticmethod
        def _getOperationShape(left_shape, right_shape):
            return left_shape.getOperationBinaryOldDivShape(right_shape)


class ExpressionOperationBinaryTrueDiv(ExpressionOperationBinaryBase):
    kind = "EXPRESSION_OPERATION_BINARY_TRUE_DIV"

    operator = "TrueDiv"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryTrueDivShape(right_shape)


class ExpressionOperationModMixin(object):
    # Mixins are not allowed to specify slots.
    __slots__ = ()

    def getValueShape(self):
        return self.shape

    def getTooLargeShape(self):
        if not self.subnode_right.isCompileTimeConstant():
            return None

        if not (
            self.subnode_left.isExpressionConstantStrRef()
            or self.subnode_left.isExpressionConstantUnicodeRef()
            or (
                self.subnode_left.isExpressionConstantBytesRef()
                and python_version >= 0x350
            )
        ):
            return None

        format_string = self.subnode_left.getCompileTimeConstant()
        rhs = self.subnode_right.getCompileTimeConstant()

        if self.subnode_left.isExpressionConstantBytesRef():
            format_string = format_string.decode("latin1")

        size_range = predictStringFormatSizeRange(format_string, rhs)

        if size_range is None:
            return None

        min_size, max_size = size_range

        if max_size > 256:
            if min_size == max_size:
                return ShapeLargeConstantValue(
                    size=max_size,
                    shape=self.subnode_left.getTypeShape(),
                )
            else:
                return ShapeLargeConstantValueRange(
                    min_size=min_size,
                    max_size=max_size,
                    shape=self.subnode_left.getTypeShape(),
                )

        return None


class ExpressionOperationBinaryMod(
    ExpressionOperationModMixin, ExpressionOperationBinaryBase
):
    kind = "EXPRESSION_OPERATION_BINARY_MOD"

    operator = "Mod"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryModShape(right_shape)


class ExpressionOperationBinaryDivmod(ExpressionOperationBinaryBase):
    kind = "EXPRESSION_OPERATION_BINARY_DIVMOD"

    operator = "Divmod"
    simulator = binary_operator_functions[operator]

    def __init__(self, left, right, source_ref):
        ExpressionOperationBinaryBase.__init__(
            self, left=left, right=right, source_ref=source_ref
        )

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryDivmodShape(right_shape)


class ExpressionOperationPowMixin(object):
    # Mixins are not allowed to specify slots.
    __slots__ = ()

    def getValueShape(self):
        return self.shape

    def getTooLargeShape(self):
        left_value = self.subnode_left.getCompileTimeConstant()
        right_value = self.subnode_right.getCompileTimeConstant()

        if _isTooLargePower(left_value, right_value):
            return ShapeLargeConstantValue(size=None, shape=tshape_int_or_long)

        return None


class ExpressionOperationBinaryPow(
    ExpressionOperationPowMixin, ExpressionOperationBinaryBase
):
    kind = "EXPRESSION_OPERATION_BINARY_POW"

    operator = "Pow"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryPowShape(right_shape)


class ExpressionOperationLshiftMixin(object):
    # Mixins are not allowed to specify slots.
    __slots__ = ()

    def getValueShape(self):
        return self.shape

    def getTooLargeShape(self):
        left_value = self.subnode_left.getCompileTimeConstant()
        right_value = self.subnode_right.getCompileTimeConstant()

        if _isTooLargeLshift(left_value, right_value):
            return ShapeLargeConstantValue(size=None, shape=tshape_int_or_long)

        return None


class ExpressionOperationBinaryLshift(
    ExpressionOperationLshiftMixin, ExpressionOperationBinaryBase
):
    kind = "EXPRESSION_OPERATION_BINARY_LSHIFT"

    operator = "LShift"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryLShiftShape(right_shape)


class ExpressionOperationBinaryRshift(ExpressionOperationBinaryBase):
    kind = "EXPRESSION_OPERATION_BINARY_RSHIFT"

    operator = "RShift"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryRShiftShape(right_shape)


class ExpressionOperationBinaryBitOr(ExpressionOperationBinaryBase):
    kind = "EXPRESSION_OPERATION_BINARY_BIT_OR"

    operator = "BitOr"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryBitOrShape(right_shape)


class ExpressionOperationBinaryBitAnd(ExpressionOperationBinaryBase):
    kind = "EXPRESSION_OPERATION_BINARY_BIT_AND"

    operator = "BitAnd"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryBitAndShape(right_shape)


class ExpressionOperationBinaryBitXor(ExpressionOperationBinaryBase):
    kind = "EXPRESSION_OPERATION_BINARY_BIT_XOR"

    operator = "BitXor"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryBitXorShape(right_shape)


if python_version >= 0x350:

    class ExpressionOperationBinaryMatMult(ExpressionOperationBinaryBase):
        kind = "EXPRESSION_OPERATION_BINARY_MAT_MULT"

        operator = "MatMult"
        simulator = binary_operator_functions[operator]

        @staticmethod
        def _getOperationShape(left_shape, right_shape):
            return left_shape.getOperationBinaryMatMultShape(right_shape)


_operator2binary_operation_node_class = {
    "Add": ExpressionOperationBinaryAdd,
    "Sub": ExpressionOperationBinarySub,
    "Mult": ExpressionOperationBinaryMult,
    "FloorDiv": ExpressionOperationBinaryFloorDiv,
    "TrueDiv": ExpressionOperationBinaryTrueDiv,
    "Mod": ExpressionOperationBinaryMod,
    # Divmod only from built-in call.
    "Pow": ExpressionOperationBinaryPow,
    "LShift": ExpressionOperationBinaryLshift,
    "RShift": ExpressionOperationBinaryRshift,
    "BitOr": ExpressionOperationBinaryBitOr,
    "BitAnd": ExpressionOperationBinaryBitAnd,
    "BitXor": ExpressionOperationBinaryBitXor,
}

if python_version < 0x300:
    _operator2binary_operation_node_class["OldDiv"] = ExpressionOperationBinaryOldDiv

if python_version >= 0x350:
    _operator2binary_operation_node_class["MatMult"] = ExpressionOperationBinaryMatMult


def makeBinaryOperationNode(operator, left, right, source_ref):
    node_class = _operator2binary_operation_node_class[operator]

    node = node_class(left=left, right=right, source_ref=source_ref)

    # Shortcut these binary operations, avoiding "1+1", "1+1j", etc. to ever
    # become an operation.
    if left.isCompileTimeConstant() and right.isCompileTimeConstant():
        # Do not compute too large constants, leave that to the optimization.
        if node.getTooLargeShape() is not None:
            return node

        try:
            constant = node.simulator(
                left.getCompileTimeConstant(), right.getCompileTimeConstant()
            )
        except Exception:  # Catch all the things, pylint: disable=broad-except
            # Compile time detectable error, postpone these, so they get traced.
            pass
        else:
            return makeConstantReplacementNode(
                constant=constant,
                node=node,
                user_provided=getattr(left, "user_provided", False),
            )

    return node


class ExpressionOperationBinaryInplaceBase(ExpressionOperationBinaryBase):
    # Base classes can be abstract, pylint: disable=abstract-method
    """Base class for all inplace operations."""

    def __init__(self, left, right, source_ref):
        ExpressionOperationBinaryBase.__init__(
            self, left=left, right=right, source_ref=source_ref
        )

        self.inplace_suspect = True

    @staticmethod
    def isExpressionOperationInplace():
        return True

    def computeExpression(self, trace_collection):
        # Nothing to do anymore for large constants.
        if self.shape is not None and self.shape.isConstant():
            exception_raise_exit = self.escape_desc.getExceptionExit()
            if exception_raise_exit is not None:
                trace_collection.onExceptionRaiseExit(exception_raise_exit)

            return self, None, None

        left = self.subnode_left
        left_shape = left.getTypeShape()
        right = self.subnode_right
        right_shape = right.getTypeShape()

        self.type_shape, self.escape_desc = self._getOperationShape(
            left_shape, right_shape
        )

        if left.isCompileTimeConstant() and right.isCompileTimeConstant():
            too_large_shape = self.getTooLargeShape()

            if too_large_shape is None:
                return self._simulateOperation(trace_collection)

            self.shape = too_large_shape

        exception_raise_exit = self.escape_desc.getExceptionExit()
        if exception_raise_exit is not None:
            trace_collection.onExceptionRaiseExit(exception_raise_exit)

            if self.escape_desc.isUnsupported() and self.canCreateUnsupportedException(
                left_shape, right_shape
            ):
                result = wrapExpressionWithSideEffects(
                    new_node=makeRaiseExceptionReplacementExpressionFromInstance(
                        expression=self,
                        exception=self.createUnsupportedException(
                            left_shape,
                            right_shape,
                        ),
                    ),
                    old_node=self,
                    side_effects=(left, right),
                )

                return (
                    result,
                    "new_raise",
                    "Replaced inplace-operator '%s' with %s %s arguments that cannot work."
                    % (self.operator, left_shape, right_shape),
                )

        if self.escape_desc.isValueEscaping():
            # The value of these nodes escaped and could change its contents.
            trace_collection.removeKnowledge(left)
            trace_collection.removeKnowledge(right)

        if self.escape_desc.isControlFlowEscape():
            # Any code could be run, note that.
            trace_collection.onControlFlowEscape(self)

        if left_shape is tshape_bool:
            result = makeBinaryOperationNode(
                self.operator[1:], left, right, self.source_ref
            )

            return trace_collection.computedExpressionResult(
                result,
                "new_expression",
                "Lowered inplace-operator '%s' to binary operation." % self.operator,
            )

        return self, None, None


class ExpressionOperationInplaceAdd(
    ExpressionOperationAddMixin, ExpressionOperationBinaryInplaceBase
):
    kind = "EXPRESSION_OPERATION_INPLACE_ADD"

    operator = "IAdd"
    simulator = binary_operator_functions[operator]

    def __init__(self, left, right, source_ref):
        ExpressionOperationBinaryInplaceBase.__init__(
            self, left=left, right=right, source_ref=source_ref
        )

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationInplaceAddShape(right_shape)


class ExpressionOperationInplaceSub(ExpressionOperationBinaryInplaceBase):
    kind = "EXPRESSION_OPERATION_INPLACE_SUB"

    operator = "ISub"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinarySubShape(right_shape)


class ExpressionOperationInplaceMult(ExpressionOperationBinaryInplaceBase):
    kind = "EXPRESSION_OPERATION_INPLACE_MULT"

    operator = "IMult"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryMultShape(right_shape)


class ExpressionOperationInplaceFloorDiv(ExpressionOperationBinaryInplaceBase):
    kind = "EXPRESSION_OPERATION_INPLACE_FLOOR_DIV"

    operator = "IFloorDiv"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryFloorDivShape(right_shape)


if python_version < 0x300:

    class ExpressionOperationInplaceOldDiv(ExpressionOperationBinaryInplaceBase):
        kind = "EXPRESSION_OPERATION_INPLACE_OLD_DIV"

        operator = "IOldDiv"
        simulator = binary_operator_functions[operator]

        @staticmethod
        def _getOperationShape(left_shape, right_shape):
            return left_shape.getOperationBinaryOldDivShape(right_shape)


class ExpressionOperationInplaceTrueDiv(ExpressionOperationBinaryInplaceBase):
    kind = "EXPRESSION_OPERATION_INPLACE_TRUE_DIV"

    operator = "ITrueDiv"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryTrueDivShape(right_shape)


class ExpressionOperationInplaceMod(
    ExpressionOperationModMixin, ExpressionOperationBinaryInplaceBase
):
    kind = "EXPRESSION_OPERATION_INPLACE_MOD"

    operator = "IMod"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryModShape(right_shape)


class ExpressionOperationInplacePow(
    ExpressionOperationPowMixin, ExpressionOperationBinaryInplaceBase
):
    kind = "EXPRESSION_OPERATION_INPLACE_POW"

    operator = "IPow"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryPowShape(right_shape)


class ExpressionOperationInplaceLshift(ExpressionOperationBinaryInplaceBase):
    kind = "EXPRESSION_OPERATION_INPLACE_LSHIFT"

    operator = "ILShift"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryLShiftShape(right_shape)


class ExpressionOperationInplaceRshift(ExpressionOperationBinaryInplaceBase):
    kind = "EXPRESSION_OPERATION_INPLACE_RSHIFT"

    operator = "IRShift"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryRShiftShape(right_shape)


class ExpressionOperationInplaceBitOr(ExpressionOperationBinaryInplaceBase):
    kind = "EXPRESSION_OPERATION_INPLACE_BIT_OR"

    operator = "IBitOr"
    simulator = binary_operator_functions[operator]

    # No inplace bitor special handling before 3.9
    if python_version < 0x390:

        @staticmethod
        def _getOperationShape(left_shape, right_shape):
            return left_shape.getOperationBinaryBitOrShape(right_shape)

    else:

        @staticmethod
        def _getOperationShape(left_shape, right_shape):
            return left_shape.getOperationInplaceBitOrShape(right_shape)


class ExpressionOperationInplaceBitAnd(ExpressionOperationBinaryInplaceBase):
    kind = "EXPRESSION_OPERATION_INPLACE_BIT_AND"

    operator = "IBitAnd"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryBitAndShape(right_shape)


class ExpressionOperationInplaceBitXor(ExpressionOperationBinaryInplaceBase):
    kind = "EXPRESSION_OPERATION_INPLACE_BIT_XOR"

    operator = "IBitXor"
    simulator = binary_operator_functions[operator]

    @staticmethod
    def _getOperationShape(left_shape, right_shape):
        return left_shape.getOperationBinaryBitXorShape(right_shape)


if python_version >= 0x350:

    class ExpressionOperationInplaceMatMult(ExpressionOperationBinaryInplaceBase):
        kind = "EXPRESSION_OPERATION_INPLACE_MAT_MULT"

        operator = "IMatMult"
        simulator = binary_operator_functions[operator]

        @staticmethod
        def _getOperationShape(left_shape, right_shape):
            return left_shape.getOperationBinaryMatMultShape(right_shape)


_operator2binary_inplace_node_class = {
    "IAdd": ExpressionOperationInplaceAdd,
    "ISub": ExpressionOperationInplaceSub,
    "IMult": ExpressionOperationInplaceMult,
    "IFloorDiv": ExpressionOperationInplaceFloorDiv,
    "ITrueDiv": ExpressionOperationInplaceTrueDiv,
    "IMod": ExpressionOperationInplaceMod,
    "IPow": ExpressionOperationInplacePow,
    "ILShift": ExpressionOperationInplaceLshift,
    "IRShift": ExpressionOperationInplaceRshift,
    "IBitOr": ExpressionOperationInplaceBitOr,
    "IBitAnd": ExpressionOperationInplaceBitAnd,
    "IBitXor": ExpressionOperationInplaceBitXor,
}

if python_version < 0x300:
    _operator2binary_inplace_node_class["IOldDiv"] = ExpressionOperationInplaceOldDiv

if python_version >= 0x350:
    _operator2binary_inplace_node_class["IMatMult"] = ExpressionOperationInplaceMatMult


def makeExpressionOperationBinaryInplace(operator, left, right, source_ref):
    node_class = _operator2binary_inplace_node_class[operator]

    return node_class(left=left, right=right, source_ref=source_ref)


#     Part of "Nuitka", an optimizing Python compiler that is compatible and
#     integrates with CPython, but also works on its own.
#
#     Licensed under the GNU Affero General Public License, Version 3 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#        https://www.gnu.org/licenses/agpl-3.0.txt
#
#     See also: "Nuitka Runtime Library Exception, Version 1.0" in file
#     "LICENSE-RUNTIME.txt" for additional permissions granted under Section 7.
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.
