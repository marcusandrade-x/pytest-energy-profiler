#     Copyright 2026, Kay Hayen, mailto:kay.hayen@gmail.com find license text at end of file


"""Templates for the loading of embedded modules."""

# Bytecode and extension modules share the importer of the entry and only need
# their load state slots generated in the loader body.
template_metapath_loader_module_state = """\
static PyObject *module_state_%(module_identifier)s = NULL;
static PyThreadState *module_owner_%(module_identifier)s = NULL;"""

template_metapath_loader_extension_module_entry = """\
%(module_state_decls)s
struct Nuitka_MetaPathBasedLoaderEntry %(entry_name)s = {
    %(module_name)s, %(get_name_func)s, %(compare_name_func)s, %(get_display_name)s, %(pre_load)s, %(post_load)s, %(parent)s, NULL, IMPORT_EMBEDDED_MODULE_ENTRY, &module_state_%(module_identifier)s, &module_owner_%(module_identifier)s, 0, 0, %(flags)s
#if defined(_NUITKA_FREEZER_HAS_FILE_PATH)
    , %(file_path)s
#endif
};"""

template_metapath_loader_bytecode_module_entry = """\
%(module_state_decls)s
struct Nuitka_MetaPathBasedLoaderEntry %(entry_name)s = {
    %(module_name)s, %(get_name_func)s, %(compare_name_func)s, %(get_display_name)s, %(pre_load)s, %(post_load)s, %(parent)s, NULL, IMPORT_EMBEDDED_MODULE_ENTRY, &module_state_%(module_identifier)s, &module_owner_%(module_identifier)s, %(bytecode)s, %(size)d, %(flags)s
#if defined(_NUITKA_FREEZER_HAS_FILE_PATH)
    , %(file_path)s
#endif
};"""

# Excluded module entries are never referenced by other entries, so unlike the
# bytecode and extension module entries, they remain private to the loader.
template_metapath_loader_excluded_module_entry = """\
static struct Nuitka_MetaPathBasedLoaderEntry %(entry_name)s = {
    %(module_name)s, %(get_name_func)s, %(compare_name_func)s, NULL, NULL, NULL, NULL, NUITKA_CAST_INIT_REASON(%(exclusion_reason)s), NULL, NULL, NULL, 0, 0, %(flags)s
#if defined(_NUITKA_FREEZER_HAS_FILE_PATH)
    , NULL
#endif
};"""


template_metapath_loader_body = r"""
/* Code to register embedded modules for meta path based loading if any. */

#include "nuitka/prelude.h"

/* Use a hex version of our own to compare for versions. We do not care about pre-releases */
#if PY_MICRO_VERSION < 16
#define PYTHON_VERSION (PY_MAJOR_VERSION * 256 + PY_MINOR_VERSION * 16 + PY_MICRO_VERSION)
#else
#define PYTHON_VERSION (PY_MAJOR_VERSION * 256 + PY_MINOR_VERSION * 16 + 15)
#endif

#include "nuitka/constants_blob.h"

#include "nuitka/tracing.h"
#include "nuitka/unfreezing.h"

/* Type bool, spell-checker: ignore stdbool */
#ifndef __cplusplus
#include <stdbool.h>
#endif

#if %(bytecode_count)d > 0
static unsigned char *bytecode_data[%(bytecode_count)d];
#else
static unsigned char **bytecode_data = NULL;
#endif

/* Helper for portable cast, to use string literals as module_init_func */
#ifdef __cplusplus
#define NUITKA_CAST_INIT_REASON(x) reinterpret_cast<module_init_func>((void*)(x))
#else
#define NUITKA_CAST_INIT_REASON(x) (module_init_func)(x)
#endif

/* Table for lookup to find compiled or bytecode modules included in this
 * binary or module, or put along this binary as extension modules. We do
 * our own loading for each of these.
 */
%(metapath_loader_decls)s

%(metapath_loader_inittab)s

static struct Nuitka_MetaPathBasedLoaderEntry *meta_path_loader_entries[%(entry_count)d] = {
%(metapath_loader_refs)s
};

static void _loadBytesCodesBlob(PyThreadState *tstate) {
    static bool init_done = false;

    if (init_done == false) {
        // Note needed for mere data.
        loadConstantsBlob(tstate, bytecode_data, ".bytecode");

        init_done = true;
    }
}

void setupMetaPathBasedLoader(PyThreadState *tstate) {
    static bool init_done = false;
    if (init_done == false) {
        _loadBytesCodesBlob(tstate);
        registerMetaPathBasedLoader(meta_path_loader_entries, bytecode_data, %(entry_count)d);

        init_done = true;
    }
}

// This provides the frozen (compiled bytecode) files that are included if
// any.

// These modules should be loaded as bytecode. They may e.g. have to be loadable
// during "Py_Initialize" already, or for irrelevance, they are only included
// in this un-optimized form. These are not compiled by Nuitka, and therefore
// are not accelerated at all, merely bundled with the binary or module, so
// that CPython library can start out finding them.

struct frozen_desc {
    char const *name;
    int index;
    int size;
};

static struct frozen_desc _frozen_modules[] = {
%(frozen_modules)s
    {NULL, 0, 0}
};


Py_ssize_t getFrozenModuleCount(void) {
    return (Py_ssize_t)(sizeof(_frozen_modules) / sizeof(_frozen_modules[0])) - 1;
}


void copyFrozenModulesTo(struct _frozen *destination) {
    NUITKA_PRINT_TIMING("copyFrozenModulesTo(): Calling _loadBytesCodesBlob.");
    _loadBytesCodesBlob(NULL);

    NUITKA_PRINT_TIMING("copyFrozenModulesTo(): Updating frozen module table sizes.");

    struct frozen_desc *current = _frozen_modules;

    for (;;) {
        destination->name = (char *)current->name;
        destination->code = bytecode_data[current->index];
        destination->size = current->size;
#if PYTHON_VERSION >= 0x3b0
        destination->is_package = current->size < 0;
        destination->size = Py_ABS(destination->size);
#if PYTHON_VERSION < 0x3d0
        destination->get_code = NULL;
#endif
#endif
        if (destination->name == NULL) break;

        current += 1;
        destination += 1;
    };
}

"""

from . import TemplateDebugWrapper  # isort:skip

TemplateDebugWrapper.checkDebug(globals())

#     Part of "Nuitka", an optimizing Python compiler that is compatible and
#     integrates with CPython, but also works on its own.
#
#     Licensed under the GNU Affero General Public License, Version 3 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#        https://www.gnu.org/licenses/agpl-3.0.txt
#
#     See also: "Nuitka Runtime Library Exception, Version 1.0" in file
#     "LICENSE-RUNTIME.txt" for additional permissions granted under Section 7.
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.
